function playAD() {
    window.ysdk.adv.showFullscreenAdv({
        callbacks: {
            onOpen: function() {
                stopSound('soundButton');
                stopMusicLoop("musicGame");
            },
            onClose: function(wasShown) {
                playSound('soundButton');
                playMusicLoop("musicGame");
                goPage('game');
            },
            onError: function(error) {
                playSound('soundButton');
                playMusicLoop("musicGame");
                goPage('game');
            },
            onOffline: function() {
                playSound('soundButton');
                playMusicLoop("musicGame");
                goPage('game');
            }
        }
    });

  }
