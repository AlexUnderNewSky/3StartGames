
////////////////////////////////////////////////////////////
// PUZZLE
////////////////////////////////////////////////////////////

/*!
 * 
 * PUZZLE SETTING CUSTOMIZATION START
 * 
 */

var puzzles_arr = [
	{
		level:0,
		puzzle:[
			{r:0, c:3, visible:true},
			{r:1, c:3, visible:true},
			{r:0, c:5, visible:true},
			{r:1, c:5, visible:true},
			{r:2, c:4, visible:false},
		],
		player:[
			{r:1, c:2},
			{r:1, c:6},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:3, visible:true},
			{r:1, c:3, visible:true},
			{r:2, c:3, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:4, visible:true},
			{r:1, c:4, visible:false},
			{r:1, c:2, visible:false},
		],
		player:[
			{r:0, c:4},
			{r:3, c:2},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:4, visible:false},
			{r:0, c:6, visible:true},
		],
		player:[
			{r:0, c:3},
			{r:0, c:5},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:1, c:2, visible:true},
			{r:2, c:2, visible:false},
			{r:0, c:5, visible:true},
			{r:1, c:5, visible:true},
		],
		player:[
			{r:0, c:3},
			{r:0, c:4},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:1, c:3, visible:false},
			{r:1, c:4, visible:true},
			{r:1, c:5, visible:true},
		],
		player:[
			{r:1, c:6},
			{r:0, c:1},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:1, c:5, visible:true},
			{r:2, c:5, visible:false},
		],
		player:[
			{r:0, c:3},
			{r:1, c:4},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:1, c:2, visible:true},
			{r:2, c:2, visible:true},
			{r:1, c:3, visible:false},
		],
		player:[
			{r:0, c:4},
			{r:0, c:5},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:1, c:2, visible:true},
			{r:0, c:4, visible:false},
		],
		player:[
			{r:1, c:3},
			{r:0, c:6},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:false},
			{r:0, c:6, visible:true},
			{r:1, c:6, visible:true},
		],
		player:[
			{r:0, c:4},
			{r:1, c:5},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:1, visible:true},
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:1, c:2, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:1, visible:false},
		],
		player:[
			{r:1, c:3},
			{r:0, c:4},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:1, c:4, visible:true},
			{r:1, c:5, visible:true},
			{r:1, c:3, visible:false},
		],
		player:[
			{r:0, c:2},
			{r:1, c:6},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:5, visible:true},
			{r:1, c:5, visible:true},
			{r:0, c:4, visible:false},
		],
		player:[
			{r:0, c:2},
			{r:0, c:3},
			{r:1, c:4},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:1, c:4, visible:true},
			{r:2, c:4, visible:true},
			{r:2, c:3, visible:false},
		],
		player:[
			{r:0, c:1},
			{r:0, c:2},
			{r:1, c:3},
			{r:2, c:5},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:5, visible:false},
		],
		player:[
			{r:1, c:2},
			{r:0, c:6},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:3, visible:true},
			{r:0, c:6, visible:false},
		],
		player:[
			{r:1, c:3},
			{r:0, c:4},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:3, visible:true},
			{r:1, c:3, visible:true},
			{r:0, c:5, visible:false},
			{r:0, c:6, visible:true},
		],
		player:[
			{r:1, c:6},
			{r:1, c:4},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:1, c:3, visible:false},
		],
		player:[
			{r:0, c:1},
			{r:0, c:5},
		]
	},
	{
		level:0,
		puzzle:[
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:1, c:5, visible:true},
			{r:1, c:6, visible:false},
		],
		player:[
			{r:0, c:6},
			{r:0, c:3},
		]
	},
	{
		level:1,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:1, c:2, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:3, visible:true},
			{r:0, c:5, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:6, visible:true},
			{r:2, c:5, visible:true},
			{r:2, c:6, visible:true},
			{r:1, c:3, visible:false},
			{r:1, c:5, visible:false},
		],
		player:[
			{r:0, c:4},
			{r:3, c:4},
		]
	},
	{
		level:1,
		puzzle:[
			{r:0, c:5, visible:true},
			{r:1, c:4, visible:true},
			{r:2, c:3, visible:true},
			{r:3, c:2, visible:false},
		],
		player:[
			{r:0, c:4},
			{r:1, c:5},
		]
	},
	{
		level:1,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:1, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:6, visible:true},
			{r:1, c:5, visible:false},
		],
		player:[
			{r:2, c:2},
			{r:1, c:3},
		]
	},
	{
		level:1,
		puzzle:[
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:false},
			{r:1, c:4, visible:true},
			{r:2, c:4, visible:true},
			{r:3, c:4, visible:true},
			{r:4, c:4, visible:false},
		],
		player:[
			{r:0, c:6},
			{r:3, c:5},
		]
	},
	{
		level:1,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:1, c:2, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:3, visible:false},
			{r:2, c:4, visible:false},
		],
		player:[
			{r:1, c:4},
			{r:0, c:5},
		]
	},
	{
		level:1,
		puzzle:[
			{r:0, c:3, visible:true},
			{r:1, c:3, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:6, visible:true},
			{r:1, c:4, visible:false},
			{r:1, c:5, visible:false},
		],
		player:[
			{r:0, c:4},
			{r:0, c:5},
		]
	},
	{
		level:1,
		puzzle:[
			{r:0, c:1, visible:true},
			{r:1, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:1, c:3, visible:true},
			{r:0, c:1, visible:false},
			{r:1, c:1, visible:false},
			{r:2, c:1, visible:false},
		],
		player:[
			{r:0, c:4},
			{r:2, c:3},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:1, c:2, visible:true},
			{r:1, c:4, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:3, visible:true},
			{r:2, c:4, visible:true},
			{r:3, c:2, visible:true},
			{r:3, c:4, visible:true},
			{r:4, c:2, visible:false},
			{r:4, c:3, visible:true},
			{r:4, c:4, visible:false},
		],
		player:[
			{r:2, c:1},
			{r:1, c:5},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:5, visible:true},
			{r:1, c:2, visible:true},
			{r:1, c:3, visible:true},
			{r:1, c:4, visible:true},
			{r:1, c:5, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:5, visible:false},
		],
		player:[
			{r:2, c:3},
			{r:0, c:6},
			{r:1, c:6},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:4, visible:true},
			{r:1, c:5, visible:true},
			{r:1, c:6, visible:true},
			{r:2, c:5, visible:true},
			{r:2, c:6, visible:true},
			{r:3, c:6, visible:true},
			{r:1, c:3, visible:false},
		],
		player:[
			{r:0, c:2},
			{r:4, c:6},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:1, visible:true},
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:1, visible:true},
			{r:1, c:2, visible:true},
			{r:1, c:3, visible:true},
			{r:1, c:4, visible:true},
			{r:2, c:1, visible:true},
			{r:2, c:2, visible:true},
			{r:3, c:1, visible:true},
			{r:1, c:6, visible:false},
		],
		player:[
			{r:3, c:2},
			{r:2, c:3},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:1, visible:true},
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:1, c:1, visible:true},
			{r:1, c:2, visible:true},
			{r:1, c:3, visible:true},
			{r:1, c:4, visible:true},
			{r:2, c:1, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:3, visible:true},
			{r:2, c:4, visible:true},
			{r:3, c:2, visible:true},
			{r:3, c:3, visible:true},
			{r:3, c:4, visible:false},
		],
		player:[
			{r:3, c:1},
			{r:1, c:5},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:1, c:2, visible:true},
			{r:1, c:3, visible:true},
			{r:1, c:4, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:3, visible:true},
			{r:3, c:2, visible:true},
			{r:0, c:5, visible:false},
		],
		player:[
			{r:4, c:2},
			{r:3, c:3},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:1, visible:true},
			{r:1, c:1, visible:true},
			{r:2, c:1, visible:true},
			{r:3, c:1, visible:true},
			{r:3, c:2, visible:true},
			{r:4, c:2, visible:true},
			{r:4, c:3, visible:true},
			{r:3, c:4, visible:true},
			{r:4, c:4, visible:false},
			{r:0, c:5, visible:true},
			{r:1, c:5, visible:true},
			{r:2, c:5, visible:true},
			{r:3, c:5, visible:true},
		],
		player:[
			{r:0, c:6},
			{r:4, c:1},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:2, visible:true},
			{r:1, c:3, visible:true},
			{r:1, c:4, visible:true},
			{r:1, c:5, visible:true},
			{r:1, c:6, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:3, visible:true},
			{r:2, c:4, visible:true},
			{r:2, c:5, visible:true},
			{r:3, c:2, visible:false},
			{r:3, c:3, visible:true},
			{r:3, c:4, visible:true},
			{r:3, c:5, visible:true},
		],
		player:[
			{r:2, c:6},
			{r:4, c:5},
			{r:4, c:4},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:1, c:2, visible:true},
			{r:1, c:3, visible:true},
			{r:1, c:4, visible:true},
			{r:2, c:2, visible:true},
			{r:2, c:3, visible:true},
			{r:2, c:4, visible:true},
			{r:3, c:3, visible:true},
			{r:3, c:4, visible:true},
			{r:3, c:5, visible:false},
		],
		player:[
			{r:3, c:1},
			{r:3, c:2},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:2, visible:true},
			{r:0, c:3, visible:true},
			{r:0, c:4, visible:true},
			{r:0, c:5, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:2, visible:true},
			{r:1, c:3, visible:true},
			{r:1, c:4, visible:true},
			{r:1, c:5, visible:true},
			{r:1, c:6, visible:true},
			{r:2, c:2, visible:true},
			{r:3, c:2, visible:true},
			{r:2, c:6, visible:true},
			{r:3, c:6, visible:true},
			{r:3, c:1, visible:false},
		],
		player:[
			{r:2, c:4},
			{r:2, c:5},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:1, visible:true},
			{r:1, c:1, visible:true},
			{r:2, c:1, visible:true},
			{r:3, c:1, visible:true},
			{r:4, c:1, visible:true},
			{r:5, c:1, visible:true},
			{r:0, c:2, visible:true},
			{r:2, c:2, visible:false},
			{r:4, c:2, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:6, visible:true},
			{r:2, c:6, visible:true},
			{r:3, c:6, visible:true},
			{r:4, c:6, visible:true},
			{r:5, c:6, visible:true},
			{r:0, c:5, visible:true},
			{r:2, c:5, visible:true},
			{r:4, c:5, visible:false},
		],
		player:[
			{r:3, c:2},
			{r:0, c:4},
		]
	},
	{
		level:2,
		puzzle:[
			{r:0, c:1, visible:true},
			{r:1, c:2, visible:true},
			{r:2, c:3, visible:true},
			{r:3, c:4, visible:true},
			{r:4, c:5, visible:true},
			{r:5, c:6, visible:true},
			{r:0, c:6, visible:true},
			{r:1, c:5, visible:true},
			{r:5, c:1, visible:true},
			{r:4, c:2, visible:true},
			{r:3, c:3, visible:false},
			{r:2, c:4, visible:false},
		],
		player:[
			{r:0, c:2},
			{r:5, c:5},
			{r:5, c:2},
		]
	},
];