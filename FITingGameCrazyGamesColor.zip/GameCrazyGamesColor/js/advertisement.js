function playAD() {
    const callbacks = {
		adFinished: () => console.log("End midgame ad") + window.CrazyGames.SDK.game.gameplayStart(playSound('soundButton'),
        playMusicLoop("musicGame"), goPage('game')),
		adError: (error) => console.log("Error midgame ad", error),
		adStarted: () => console.log("Start midgame ad") + window.CrazyGames.SDK.game.gameplayStop(stopSound('soundButton'),
        stopMusicLoop("musicGame"), stopGame()),
	  };
      window.addEventListener("wheel", (event) => event.preventDefault(), {
        passive: false,
      });
      
      window.addEventListener("keydown", (event) => {
        if (["ArrowUp", "ArrowDown", " "].includes(event.key)) {
          event.preventDefault();
        }
      });
      
      window.CrazyGames.SDK.ad.requestAd("midgame", callbacks);    
  }
