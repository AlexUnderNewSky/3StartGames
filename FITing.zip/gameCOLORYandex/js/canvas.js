////////////////////////////////////////////////////////////
// CANVAS
////////////////////////////////////////////////////////////
var stage
var canvasW=0;
var canvasH=0;

/*!
 * 
 * START GAME CANVAS - This is the function that runs to setup game canvas
 * 
 */
function initGameCanvas(w,h){
	var gameCanvas = document.getElementById("gameCanvas");
	gameCanvas.width = w;
	gameCanvas.height = h;
	
	canvasW=w;
	canvasH=h;
	stage = new createjs.Stage("gameCanvas");
	
	createjs.Touch.enable(stage);
	stage.enableMouseOver(20);
	stage.mouseMoveOutside = true;
	
	createjs.Ticker.timingMode = createjs.Ticker.RAF_SYNCHED;
	createjs.Ticker.framerate = 50;
	createjs.Ticker.addEventListener("tick", tick);
}

var guide = false;
var canvasContainer, mainContainer, gameContainer, resultContainer, confirmContainer, changeColorContainer;
var guideline, bg, logo, buttonOk, result, shadowResult, buttonReplay, buttonFacebook, buttonTwitter, buttonWhatsapp, buttonFullscreen, buttonSoundOn, buttonSoundOff;

/*!
 * 
 * BUILD GAME CANVAS ASSERTS - This is the function that runs to build game canvas asserts
 * 
 */
function buildGameCanvas(){
	canvasContainer = new createjs.Container();
	mainContainer = new createjs.Container();
	gameContainer = new createjs.Container();
	worldContainer = new createjs.Container();
	guideContainer = new createjs.Container();
	objectsContainer = new createjs.Container();
	resultContainer = new createjs.Container();
	changeColorContainer = new createjs.Container();
	confirmContainer = new createjs.Container();
	
	bg = new createjs.Bitmap(loader.getResult('bg'));
	bgP = new createjs.Bitmap(loader.getResult('bgP'));
	logo = new createjs.Bitmap(loader.getResult('logo'));
	logoP = new createjs.Bitmap(loader.getResult('logoP'));
	
	buttonPlay = new createjs.Bitmap(loader.getResult('buttonPlay'));
	centerReg(buttonPlay);

	buttonChangeCubeColor = new createjs.Bitmap(loader.getResult('buttonChangeCubeColor'));
	centerReg(buttonChangeCubeColor);

	colorMenu = new createjs.Bitmap(loader.getResult('colorMenu'));
	centerReg(colorMenu);

	cubeDefault = new createjs.Bitmap(loader.getResult('cubeDefault'));
	cubeGreen = new createjs.Bitmap(loader.getResult('cubeGreen'));
	cubePurple = new createjs.Bitmap(loader.getResult('cubePurple'));
	cubeBlack = new createjs.Bitmap(loader.getResult('cubeBlack'));
	cubeCyan = new createjs.Bitmap(loader.getResult('cubeCyan'));
	cubePink = new createjs.Bitmap(loader.getResult('cubePink'));
	cubeSilver = new createjs.Bitmap(loader.getResult('cubeSilver'));
	cubeGold = new createjs.Bitmap(loader.getResult('cubeGold'));
	cubeRainbow = new createjs.Bitmap(loader.getResult('cubeRainbow'));

	itemColor = new createjs.Bitmap(loader.getResult('itemPop'));
	itemColorP = new createjs.Bitmap(loader.getResult('itemPopP'));

	gameBestScoreTxt = new createjs.Text();
	gameBestScoreTxt.font = "50px russo_oneregular";
	gameBestScoreTxt.color = '#fff';
	gameBestScoreTxt.textAlign = "center";
	gameBestScoreTxt.textBaseline='alphabetic';
	gameBestScoreTxt.text = "Лучший счёт: " + localStorage.getItem("Best Score");

	//game
	bgGame = new createjs.Bitmap(loader.getResult('bgGame'));
	bgGameP = new createjs.Bitmap(loader.getResult('bgGameP'));

	bgGradient = new createjs.Bitmap(loader.getResult('bgGradient'));
	bgGradientP = new createjs.Bitmap(loader.getResult('bgGradientP'));
	centerReg(bgGradient);
	centerReg(bgGradientP);

	gameInstructionTxt = new createjs.Text();
	gameInstructionTxt.font = "25px russo_oneregular";
	gameInstructionTxt.color = '#fff';
	gameInstructionTxt.textAlign = "center";
	gameInstructionTxt.textBaseline='alphabetic';

	gameScoreTxt = new createjs.Text();
	gameScoreTxt.font = "50px russo_oneregular";
	gameScoreTxt.color = '#fff';
	gameScoreTxt.textAlign = "center";
	gameScoreTxt.textBaseline='alphabetic';
	gameScoreTxt.text = "1,400PTS";

	//result
	itemResult = new createjs.Bitmap(loader.getResult('itemPop'));
	itemResultP = new createjs.Bitmap(loader.getResult('itemPopP'));
	
	buttonContinue = new createjs.Bitmap(loader.getResult('buttonContinue'));
	centerReg(buttonContinue);

	buttonADContinue = new createjs.Bitmap(loader.getResult('buttonADContinue'));
	centerReg(buttonADContinue);
	
	resultShareTxt = new createjs.Text();
	resultShareTxt.font = "30px russo_oneregular";
	resultShareTxt.color = '#21cc14';
	resultShareTxt.textAlign = "center";
	resultShareTxt.textBaseline='alphabetic';
	resultShareTxt.text = textDisplay.share;
	
	resultDescTxt = new createjs.Text();
	resultDescTxt.font = "65px russo_oneregular";
	resultDescTxt.color = '#424553';
	resultDescTxt.textAlign = "center";
	resultDescTxt.textBaseline='alphabetic';
	resultDescTxt.text = '';

	resultTitleTxt = new createjs.Text();
	resultTitleTxt.font = "60px russo_oneregular";
	resultTitleTxt.color = "#407093";
	resultTitleTxt.textAlign = "center";
	resultTitleTxt.textBaseline='alphabetic';
	resultTitleTxt.text = textDisplay.resultTitle;

	resultAdTxt = new createjs.Text();
	resultAdTxt.font = "32px russo_oneregular";
	resultAdTxt.color = "#424553";
	resultAdTxt.textAlign = "center";
	resultAdTxt.textBaseline='alphabetic';
	resultAdTxt.text = textDisplay.resultAd;
	
	buttonFacebook = new createjs.Bitmap(loader.getResult('buttonFacebook'));
	buttonTwitter = new createjs.Bitmap(loader.getResult('buttonTwitter'));
	buttonWhatsapp = new createjs.Bitmap(loader.getResult('buttonWhatsapp'));
	centerReg(buttonFacebook);
	createHitarea(buttonFacebook);
	centerReg(buttonTwitter);
	createHitarea(buttonTwitter);
	centerReg(buttonWhatsapp);
	createHitarea(buttonWhatsapp);
	
	buttonFullscreen = new createjs.Bitmap(loader.getResult('buttonFullscreen'));
	centerReg(buttonFullscreen);
	buttonSoundOn = new createjs.Bitmap(loader.getResult('buttonSoundOn'));
	centerReg(buttonSoundOn);
	buttonSoundOff = new createjs.Bitmap(loader.getResult('buttonSoundOff'));
	centerReg(buttonSoundOff);
	buttonSoundOn.visible = false;
	buttonMusicOn = new createjs.Bitmap(loader.getResult('buttonMusicOn'));
	centerReg(buttonMusicOn);
	buttonMusicOff = new createjs.Bitmap(loader.getResult('buttonMusicOff'));
	centerReg(buttonMusicOff);
	buttonMusicOn.visible = false;
	
	buttonExit = new createjs.Bitmap(loader.getResult('buttonExit'));
	centerReg(buttonExit);
	buttonSettings = new createjs.Bitmap(loader.getResult('buttonSettings'));
	centerReg(buttonSettings);
	
	createHitarea(buttonFullscreen);
	createHitarea(buttonSoundOn);
	createHitarea(buttonSoundOff);
	createHitarea(buttonMusicOn);
	createHitarea(buttonMusicOff);
	createHitarea(buttonExit);
	createHitarea(buttonSettings);
	optionsContainer = new createjs.Container();
	optionsContainer.addChild( buttonSoundOn, buttonSoundOff, buttonMusicOn, buttonMusicOff, buttonExit);
	optionsContainer.visible = false;
	
	//exit
	itemExit = new createjs.Bitmap(loader.getResult('itemPop'));
	itemExitP = new createjs.Bitmap(loader.getResult('itemPopP'));
	
	buttonConfirm = new createjs.Bitmap(loader.getResult('buttonConfirm'));
	centerReg(buttonConfirm);
	
	buttonCancel = new createjs.Bitmap(loader.getResult('buttonCancel'));
	centerReg(buttonCancel);
	
	popDescTxt = new createjs.Text();
	popDescTxt.font = "40px russo_oneregular";
	popDescTxt.lineHeight = 40;
	popDescTxt.color = "#424553";
	popDescTxt.textAlign = "center";
	popDescTxt.textBaseline='alphabetic';
	popDescTxt.text = textDisplay.exitMessage;

	exitTitleTxt = new createjs.Text();
	exitTitleTxt.font = "60px russo_oneregular";
	exitTitleTxt.color = "#407093";
	exitTitleTxt.textAlign = "center";
	exitTitleTxt.textBaseline='alphabetic';
	exitTitleTxt.text = textDisplay.exitTitle;
	
	confirmContainer.addChild(itemExit, itemExitP, popDescTxt, exitTitleTxt, buttonConfirm, buttonCancel);
	confirmContainer.visible = false;
	
	if(guide){
		guideline = new createjs.Shape();	
		guideline.graphics.setStrokeStyle(2).beginStroke('red').drawRect((stageW-contentW)/2, (stageH-contentH)/2, contentW, contentH);
	}
	
	mainContainer.addChild(logo, logoP, buttonPlay, gameBestScoreTxt, buttonChangeCubeColor);
	worldContainer.addChild(guideContainer, bgGradientP, bgGradient, objectsContainer);
	gameContainer.addChild(bgGame, bgGameP, worldContainer, gameInstructionTxt, gameScoreTxt);

	resultContainer.addChild(itemResult, itemResultP, buttonContinue, buttonADContinue, resultDescTxt, resultTitleTxt, resultAdTxt);
	
	if(shareEnable){
		resultContainer.addChild(resultShareTxt, buttonFacebook, buttonTwitter, buttonWhatsapp);
	}
	changeColorContainer.addChild(itemColor, itemColorP, cubeDefault, cubeGreen, cubePurple, cubeBlack, cubeCyan, cubePink, cubeSilver, cubeGold, cubeRainbow, colorMenu);
	
	canvasContainer.addChild(bg, bgP, mainContainer, gameContainer, resultContainer, confirmContainer, optionsContainer, buttonSettings, guideline, changeColorContainer);
	stage.addChild(canvasContainer);
	
	changeViewport(viewport.isLandscape);
	resizeGameFunc();
}

function changeViewport(isLandscape){
	if(isLandscape){
		//landscape
		stageW=landscapeSize.w;
		stageH=landscapeSize.h;
		contentW = landscapeSize.cW;
		contentH = landscapeSize.cH;
	}else{
		//portrait
		stageW=portraitSize.w;
		stageH=portraitSize.h;
		contentW = portraitSize.cW;
		contentH = portraitSize.cH;
	}
	
	gameCanvas.width = stageW;
	gameCanvas.height = stageH;
	
	canvasW=stageW;
	canvasH=stageH;
	
	changeCanvasViewport();
}

function changeCanvasViewport(){
	if(canvasContainer!=undefined){

		if(viewport.isLandscape){
			bg.visible = true;
			bgP.visible = false;

			logo.visible = true;
			logoP.visible = false;

			buttonPlay.x = canvasW/2;
			buttonPlay.y = canvasH/100 * 80;

			buttonChangeCubeColor.x = canvasW/1.12;
			buttonChangeCubeColor.y = canvasH/1340 * 80;

			colorMenu.x = canvasW/2;
			colorMenu.y = canvasH/100 * 80;

			cubeDefault.x = canvasW/2.99;
			cubeDefault.y = canvasH/400 * 80;
			cubeGreen.x = canvasW/2.255;
			cubeGreen.y = canvasH/400 * 80;
			cubePurple.x = canvasW/1.81;
			cubePurple.y = canvasH/400 * 80;
			cubeBlack.x = canvasW/2.99;
			cubeBlack.y = canvasH/210 * 80;
			cubeCyan.x = canvasW/2.255;
			cubeCyan.y = canvasH/210 * 80;
			cubePink.x = canvasW/1.81;
			cubePink.y = canvasH/210 * 80;
			cubeSilver.x = canvasW/2.99;
			cubeSilver.y = canvasH/142.55 * 80;
			cubeGold.x = canvasW/2.255;
			cubeGold.y = canvasH/142.55 * 80;
			cubeRainbow.x = canvasW/1.81;
			cubeRainbow.y = canvasH/142.55 * 80;

			//game
			bgGame.visible = true;
			bgGameP.visible = false;

			bgGradient.visible = true;
			bgGradientP.visible = false;
			
			//result
			itemResult.visible = true;
			itemResultP.visible = false;

			itemColor.visible = true;
			itemColorP.visible = false;
			
			buttonFacebook.x = canvasW/100*43;
			buttonFacebook.y = canvasH/100*58;
			buttonTwitter.x = canvasW/2;
			buttonTwitter.y = canvasH/100*58;
			buttonWhatsapp.x = canvasW/100*57;
			buttonWhatsapp.y = canvasH/100*58;
			
			
			buttonContinue.x = canvasW/2;
			buttonContinue.y = canvasH/100 * 72;

			buttonADContinue.x = canvasW/2;
			buttonADContinue.y = canvasH/100 * 58;
	
			resultShareTxt.x = canvasW/2;
			resultShareTxt.y = canvasH/100 * 52;
	
			resultDescTxt.x = canvasW/2;
			resultDescTxt.y = canvasH/100 * 40;

			resultAdTxt.x = canvasW/2;
			resultAdTxt.y = canvasH/100 * 46.5;

			resultTitleTxt.x = canvasW/2;
			resultTitleTxt.y = canvasH/100 * 29;
			
			//exit
			itemExit.visible = true;
			itemExitP.visible = false;

			buttonConfirm.x = (canvasW/2);
			buttonConfirm.y = (canvasH/100 * 59);
			
			buttonCancel.x = (canvasW/2);
			buttonCancel.y = (canvasH/100 * 71);
			
			popDescTxt.x = canvasW/2;
			popDescTxt.y = canvasH/100 * 38;

			exitTitleTxt.x = canvasW/2;
			exitTitleTxt.y = canvasH/100 * 29;

		}else{
			bg.visible = false;
			bgP.visible = true;

			logo.visible = false;
			logoP.visible = true;

			itemResult.visible = false;
			itemResultP.visible = true;
			
			buttonPlay.x = canvasW/2;
			buttonPlay.y = canvasH/100 * 75;

			colorMenu.x = canvasW/2;
			colorMenu.y = canvasH/100 * 80;

			cubeDefault.x = canvasW/4.45;
			cubeDefault.y = canvasH/290 * 80;
			cubeGreen.x = canvasW/2.46;
			cubeGreen.y = canvasH/290 * 80;
			cubePurple.x = canvasW/1.7;
			cubePurple.y = canvasH/290 * 80;
			cubeBlack.x = canvasW/4.45;
			cubeBlack.y = canvasH/191 * 80;
			cubeCyan.x = canvasW/2.46;
			cubeCyan.y = canvasH/191 * 80;
			cubePink.x = canvasW/1.7;
			cubePink.y = canvasH/191 * 80;
			cubeSilver.x = canvasW/4.45;
			cubeSilver.y = canvasH/142.55 * 80;
			cubeGold.x = canvasW/2.46;
			cubeGold.y = canvasH/142.55 * 80;
			cubeRainbow.x = canvasW/1.7;
			cubeRainbow.y = canvasH/142.55 * 80;

			//game
			bgGame.visible = false;
			bgGameP.visible = true;

			bgGradient.visible = false;
			bgGradientP.visible = true;
			
			//result
			itemColor.visible = false;
			itemColorP.visible = true;
			
			buttonFacebook.x = canvasW/100*39;
			buttonFacebook.y = canvasH/100*55;
			buttonTwitter.x = canvasW/2;
			buttonTwitter.y = canvasH/100*55;
			buttonWhatsapp.x = canvasW/100*61;
			buttonWhatsapp.y = canvasH/100*55;
			
			buttonContinue.x = canvasW/2;
			buttonContinue.y = canvasH/100 * 65;

			buttonADContinue.x = canvasW/2;
			buttonADContinue.y = canvasH/100 * 55;
	
			resultShareTxt.x = canvasW/2;
			resultShareTxt.y = canvasH/100 * 51;
	
			resultDescTxt.x = canvasW/2;
			resultDescTxt.y = canvasH/100 * 42;

			resultAdTxt.x = canvasW/2;
			resultAdTxt.y = canvasH/100 * 48;

			resultTitleTxt.x = canvasW/2;
			resultTitleTxt.y = canvasH/100 * 34;
			
			//exit
			itemExit.visible = false;
			itemExitP.visible = true;

			buttonConfirm.x = (canvasW/2);
			buttonConfirm.y = (canvasH/100 * 57);
			
			buttonCancel.x = (canvasW/2);
			buttonCancel.y = (canvasH/100 * 66);
			
			popDescTxt.x = canvasW/2;
			popDescTxt.y = canvasH/100 * 41;

			exitTitleTxt.x = canvasW/2;
			exitTitleTxt.y = canvasH/100 * 35;
		}
	}
}

if(localStorage.getItem("Best Score") < 1){
localStorage.setItem("Best Score", 0)
}

function updateBestScore()
{
	gameBestScoreTxt.text = "Лучший счёт: " + localStorage.getItem("Best Score");
}

/*!
 * 
 * RESIZE GAME CANVAS - This is the function that runs to resize game canvas
 * 
 */
function resizeCanvas(){
 	if(canvasContainer!=undefined){
		
		buttonSettings.x = (canvasW - offset.x) - 50;
		buttonSettings.y = offset.y + 45;

		buttonChangeCubeColor.x = (canvasW - offset.x) - 140;
		buttonChangeCubeColor.y = offset.y + 45;

		if(!viewport.isLandscape){
			buttonChangeCubeColor.x = canvasW / 2;
			buttonChangeCubeColor.y = offset.y + 865;
		}
		
		var distanceNum = 60;
		var nextCount = 0;
		if(curPage != 'game' && curPage != 'result' && curPage != 'ADgame'){
			buttonExit.visible = false;
			buttonSoundOn.x = buttonSoundOff.x = buttonSettings.x;
			buttonSoundOn.y = buttonSoundOff.y = buttonSettings.y+distanceNum;
			buttonSoundOn.x = buttonSoundOff.x;
			buttonSoundOn.y = buttonSoundOff.y = buttonSettings.y+distanceNum;
			

			if (typeof buttonMusicOn != "undefined") {
				buttonMusicOn.x = buttonMusicOff.x = buttonSettings.x;
				buttonMusicOn.y = buttonMusicOff.y = buttonSettings.y+(distanceNum*2);
				buttonMusicOn.x = buttonMusicOff.x;
				buttonMusicOn.y = buttonMusicOff.y = buttonSettings.y+(distanceNum*2);
				nextCount = 2;
			}else{
				nextCount = 1;
			}
			
			// buttonFullscreen.x = buttonSettings.x;
			// buttonFullscreen.y = buttonSettings.y+(distanceNum*(nextCount+1));

		}else{
			buttonExit.visible = true
			buttonSoundOn.x = buttonSoundOff.x = buttonSettings.x;
			buttonSoundOn.y = buttonSoundOff.y = buttonSettings.y+distanceNum;
			buttonSoundOn.x = buttonSoundOff.x;
			buttonSoundOn.y = buttonSoundOff.y = buttonSettings.y+distanceNum;

			if (typeof buttonMusicOn != "undefined") {
				buttonMusicOn.x = buttonMusicOff.x = buttonSettings.x;
				buttonMusicOn.y = buttonMusicOff.y = buttonSettings.y+(distanceNum*2);
				buttonMusicOn.x = buttonMusicOff.x;
				buttonMusicOn.y = buttonMusicOff.y = buttonSettings.y+(distanceNum*2);
				nextCount = 2;
			}else{
				nextCount = 1;
			}
			
			// buttonFullscreen.x = buttonSettings.x;
			// buttonFullscreen.y = buttonSettings.y+(distanceNum*(nextCount+1));

			buttonExit.x = buttonSettings.x;
			buttonExit.y = buttonSettings.y+(distanceNum*(nextCount+1));
		}

		resizeGameLayout();
	}
}

/*!
 * 
 * REMOVE GAME CANVAS - This is the function that runs to remove game canvas
 * 
 */
 function removeGameCanvas(){
	 stage.autoClear = true;
	 stage.removeAllChildren();
	 stage.update();
	 createjs.Ticker.removeEventListener("tick", tick);
	 createjs.Ticker.removeEventListener("tick", stage);
 }

/*!
 * 
 * CANVAS LOOP - This is the function that runs for canvas loop
 * 
 */ 
function tick(event) {
	updateGame(event);
	stage.update(event);
}

/*!
 * 
 * CANVAS MISC FUNCTIONS
 * 
 */
function centerReg(obj){
	obj.regX=obj.image.naturalWidth/2;
	obj.regY=obj.image.naturalHeight/2;
}

function createHitarea(obj){
	obj.hitArea = new createjs.Shape(new createjs.Graphics().beginFill("#000").drawRect(0, 0, obj.image.naturalWidth, obj.image.naturalHeight));	
}