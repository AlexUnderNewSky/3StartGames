
////////////////////////////////////////////////////////////
// GAME v1.2
////////////////////////////////////////////////////////////

/*!
 * 
 * GAME SETTING CUSTOMIZATION START
 * 
 */

var gameSettings = {
	world:{
		size:50,
		row:6,
		column:8,
		keyboardSpeed:.2, //keyboard move speed
		touchSpeed:.1, //touch move speed
		puzzleSpeed:.8 //puzzle move speed
	},
	colors:{
		player:["#FF102D","#FF334C","#C30018"],
		puzzle:["#afafaf","#d8d8d8","#848484"],
		wall:["#ccc","#fff","#999"],
		block:["#ccc","#fff","#999"],
	},
	keyboard:{ //keyboard code
		left:[37,65],
		right:[39,68],
		up:[38,87],
		down:[40,83],
	},
	levels:[
		{
            level:0, //level difficulty from puzzles_arr array
            nextTarget:4, //total target to proceed next level
            speedIncrease:.01, //speed increase
            score:100 //score
        },
		{
			level:1,
			nextTarget:3,
			speedIncrease:.01,
			score:200
		},
		{
			level:2,
			nextTarget:5,
			speedIncrease:.01,
			score:300
		}
	]
}

//game test display
var textDisplay = {
	instructionDesktop:"ДВИГАЙ КВАДРАТ ДЛЯ СТАРТА\n(НАЖМИ ИЛИ ЗАЖМИ W,A,S,D)",
	instructionMobile:"ДВИГАЙ КВАДРАТ ДЛЯ СТАРТА\n(ЗАЖМИ)",
	score:"[NUMBER] ОЧКОВ",
	exitTitle:"ВЫЙТИ",
	exitMessage:'Ты уверен(а),\nчто хочешь\nвыйти из игры?',
	resultTitle:"КОНЕЦ ИГРЫ",
	share:'share SCORE',
	resultDesc:'[NUMBER] ОЧКОВ',
	bestScore:"[NUMBER] ОЧКОВ",
	resultAd:'Хочешь сохранить очки?'
}

//Social share, [SCORE] will replace with game score
var shareEnable = false; //toggle share
var shareTitle = 'Highscore on Hit Hole is [SCORE]PTS';//social share score title
var shareMessage = '[SCORE]PTS is mine new highscore on Hit Hole game! Try it now!'; //social share score message

/*!
 *
 * GAME SETTING CUSTOMIZATION END
 *
 */
$.editor = {enable:false};
var playerData = {score:0};
var gameData = {paused:true, square:[]};
var tweenData = {score:0, tweenScore:0};

/*!
 * 
 * GAME BUTTONS - This is the function that runs to setup button event
 * 
 */
function buildGameButton(){
	$(window).focus(function() {
		if(!buttonSoundOn.visible){
			toggleSoundInMute(false);
		}

		if (typeof buttonMusicOn != "undefined") {
			if(!buttonMusicOn.visible){
				toggleMusicInMute(false);
			}
		}
	});
	
	$(window).blur(function() {
		if(!buttonSoundOn.visible){
			toggleSoundInMute(true);
		}

		if (typeof buttonMusicOn != "undefined") {
			if(!buttonMusicOn.visible){
				toggleMusicInMute(true);
			}
		}
	});

	if($.browser.mobile || isTablet){

	}else{
		var isInIframe = (window.location != window.parent.location) ? true : false;
		if(isInIframe){
			this.document.onkeydown = keydown;
			this.document.onkeyup = keyup;
		
			$(window).blur(function() {
				appendFocusFrame();
			});
			appendFocusFrame();
        }else{
            this.document.onkeydown = keydown;
			this.document.onkeyup = keyup;
        }
	}

	buttonPlay.cursor = "pointer";
	buttonPlay.addEventListener("click", function(evt) {
		playSound('soundButton');
		playAD();
	});


	buttonChangeCubeColor.cursor = "pointer";
	buttonChangeCubeColor.addEventListener("click", function(evt) {
		goPage('color');
	});

	
	colorMenu.cursor = "pointer";
	colorMenu.addEventListener("click", function(evt) {
		goPage('main');
	});

	cubeDefault.cursor = "pointer";
	cubeDefault.addEventListener("click", function(evt) {
		gameSettings.colors.player = ["#FF102D","#FF334C","#C30018"];	
		goPage('main');
	});
	cubeGreen.cursor = "pointer";
	cubeGreen.addEventListener("click", function(evt) {
		if(localStorage.getItem("Best Score") >= 1000){
		gameSettings.colors.player = ["#0fff54","#65ff74","#64d76b"];
		goPage('main');
	}else{
		alert("К сожалению, ты не можешь использовать этот цвет, твой лучший результат меньше 1000 :c");
	}
	});
	cubePurple.cursor = "pointer";
	cubePurple.addEventListener("click", function(evt) {
		if(localStorage.getItem("Best Score") >= 2000){
			gameSettings.colors.player = ["#cf0fff","#db55ff","#b065c3"];
			goPage('main');
		}else{
			alert("К сожалению, ты не можешь использовать этот цвет, твой лучший результат меньше 2000 :c");
		}
	});
	cubeBlack.cursor = "pointer";
	cubeBlack.addEventListener("click", function(evt) {
		if(localStorage.getItem("Best Score") >= 3500){
			gameSettings.colors.player = ["#080808","#2d2d2d","#525252"];
			goPage('main');
		}else{
			alert("К сожалению, ты не можешь использовать этот цвет, твой лучший результат меньше 3500 :c");
		}
	});
	cubeCyan.cursor = "pointer";
	cubeCyan.addEventListener("click", function(evt) {
		if(localStorage.getItem("Best Score") >= 5500){
			gameSettings.colors.player = ["#18f5db","#8efae7","#64d0be"];
			goPage('main');
		}else{
			alert("К сожалению, ты не можешь использовать этот цвет, твой лучший результат меньше 5500 :c");
			 
		}
	});
	cubePink.cursor = "pointer";
	cubePink.addEventListener("click", function(evt) {
		if(localStorage.getItem("Best Score") >= 7500){
			gameSettings.colors.player = ["#ff007f","#ea006f","#f50077"];
			goPage('main');
		}else{
			alert("К сожалению, ты не можешь использовать этот цвет, твой лучший результат меньше 7500 :c");
		}
	});
	cubeSilver.cursor = "pointer";
	cubeSilver.addEventListener("click", function(evt) {
		if(localStorage.getItem("Best Score") >= 11000){
			gameSettings.colors.player = ["rgba(192, 192, 192, 0.5)","rgba(192, 192, 192, 0.7)","rgba(192, 192, 192, 1)"];
			goPage('main');
		}else{
			alert("К сожалению, ты не можешь использовать этот цвет, твой лучший результат меньше 11000 :c");
		}
	});
	cubeGold.cursor = "pointer";
	cubeGold.addEventListener("click", function(evt) {
		if(localStorage.getItem("Best Score") >= 15500){
		gameSettings.colors.player = ["rgba(255, 215, 0, 0.5)","rgba(255, 215, 0, 0.7)","rgba(255, 215, 0, 1)"];
		goPage('main');
		}else{
			alert("К сожалению, ты не можешь использовать этот цвет, твой лучший результат меньше 15500 :c");
	}
	});
	cubeRainbow.cursor = "pointer";
	cubeRainbow.addEventListener("click", function(evt) {
		if(localStorage.getItem("Best Score") >= 25000){
			gameSettings.colors.player = ["rgba(162, 8, 30, 0.5)","rgba(165, 165, 21, 0.7)","rgba(15, 13, 195, 1)"];
			goPage('main');
		}else{
			alert("К сожалению, ты не можешь использовать этот цвет, твой лучший результат меньше 25000 :c");
		}
	});

	itemExit.addEventListener("click", function(evt) {
	});
	
	
	buttonContinue.cursor = "pointer";
	buttonContinue.addEventListener("click", function(evt) {
		playSound('soundButton');
		playAD();
	});

	buttonADContinue.cursor = "pointer";
	buttonADContinue.addEventListener("click", function(evt) {
		stopSound('soundButton');
		stopMusicLoop("musicGame");
		window.ysdk.adv.showRewardedVideo({
			callbacks: {
				onOpen: () => {
					stopSound('soundButton');
					stopMusicLoop("musicGame");
					stopGame();
				},
				onRewarded: () => {
					
				},
				onClose: () => {
					playSound('soundButton');
					playMusicLoop("musicGame");
					goPage('ADgame');
				}, 
				onError: (e) => {
					playSound('soundButton');
					playMusicLoop("musicGame");
					goPage('ADgame');
				}
			}
		})
	});

	
	buttonFacebook.cursor = "pointer";
	buttonFacebook.addEventListener("click", function(evt) {
		share('facebook');
	});
	
	buttonTwitter.cursor = "pointer";
	buttonTwitter.addEventListener("click", function(evt) {
		share('twitter');
	});
	buttonWhatsapp.cursor = "pointer";
	buttonWhatsapp.addEventListener("click", function(evt) {
		share('whatsapp');
	});
	
	buttonSoundOff.cursor = "pointer";
	buttonSoundOff.addEventListener("click", function(evt) {
		toggleSoundMute(true);
	});
	
	buttonSoundOn.cursor = "pointer";
	buttonSoundOn.addEventListener("click", function(evt) {
		toggleSoundMute(false);
	});

	if (typeof buttonMusicOff != "undefined") {
		buttonMusicOff.cursor = "pointer";
		buttonMusicOff.addEventListener("click", function(evt) {
			toggleMusicMute(true);
		});
	}
	
	if (typeof buttonMusicOn != "undefined") {
		buttonMusicOn.cursor = "pointer";
		buttonMusicOn.addEventListener("click", function(evt) {
			toggleMusicMute(false);
		});
	}
	
	buttonFullscreen.cursor = "pointer";
	buttonFullscreen.addEventListener("click", function(evt) {
		toggleFullScreen();
	});
	
	buttonExit.cursor = "pointer";
	buttonExit.addEventListener("click", function(evt) {
		togglePop(true);
		toggleOption();

	});
	
	buttonSettings.cursor = "pointer";
	buttonSettings.addEventListener("click", function(evt) {
		toggleOption();
	});
	
	buttonConfirm.cursor = "pointer";
	buttonConfirm.addEventListener("click", function(evt) {
		playSound('soundButton');
		togglePop(false);
		
		stopAudio();
		stopGame();
		updateBestScore();
		goPage('main');
	});
	
	buttonCancel.cursor = "pointer";
	buttonCancel.addEventListener("click", function(evt) {
		playSound('soundButton');
		togglePop(false);
	});

	worldContainer.addEventListener("mousedown", function(evt) {
		evt.target.offset = {x:stage.mouseX, y:stage.mouseY};
	});

	worldContainer.addEventListener("pressmove", function(evt) {
		if(!gameData.animating && gameData.touchCon && gameData.playerMove){
			var moveX = ((stage.mouseX) - evt.target.offset.x);
			var moveY = ((stage.mouseY) - evt.target.offset.y);

			var dir = "";
			if(Math.abs(moveX) > 10 || Math.abs(moveY) > 10){
				if(Math.abs(moveX) > Math.abs(moveY)){
					if(moveX > 0){
						dir = "right";
					}else{
						dir = "left";
					}
				}else{
					if(moveY > 0){
						dir = "down";
					}else{
						dir = "up";
					}
				}
				
				if(dir != ""){
					gameData.player.due = dir;
					checkNextMove(false);
				}
			}
		}else{
			evt.target.offset = {x:stage.mouseX, y:stage.mouseY};
		}
	});

	preventScrolling();
}

function preventScrolling(){
	var keys = [32,38,37,40,39];
    $(window).on( "keydown", function(event) {
      if(keys.indexOf(event.keyCode) != -1){
        event.preventDefault();
      }
    });
}

function appendFocusFrame(){
	$('#mainHolder').prepend('<div id="focus" style="position:absolute; width:100%; height:100%; z-index:1000;"></div');
	$('#focus').remove();
	$('#focus').remove();
	$('#focus').remove();
	$('#focus').remove();
	$('#focus').remove();
	$('#focus').remove();
	$('#focus').remove();
	$('#focus').remove();
}

/*!
 * 
 * KEYBOARD EVENTS - This is the function that runs for keyboard events
 * 
 */
function keydown(event) {
	if(curPage == "game" || curPage == "ADgame" && gameData.playerMove){
		if(gameSettings.keyboard.left.indexOf(event.keyCode) != -1){
			gameData.moveControl.left = true;
		}else if(gameSettings.keyboard.right.indexOf(event.keyCode) != -1){
			gameData.moveControl.right = true;
		}else if(gameSettings.keyboard.up.indexOf(event.keyCode) != -1){
			gameData.moveControl.up = true;
		}else if(gameSettings.keyboard.down.indexOf(event.keyCode) != -1){
			gameData.moveControl.down = true;
		}
	}
}

function keyup(event) {
	if(curPage == "game" || curPage == "ADgame"){
		if(gameSettings.keyboard.left.indexOf(event.keyCode) != -1){
			gameData.moveControl.left = false;
		}else if(gameSettings.keyboard.right.indexOf(event.keyCode) != -1){
			gameData.moveControl.right = false;
		}else if(gameSettings.keyboard.up.indexOf(event.keyCode) != -1){
			gameData.moveControl.up = false;
		}else if(gameSettings.keyboard.down.indexOf(event.keyCode) != -1){
			gameData.moveControl.down = false;
		}
	}
}


/*!
 * 
 * TOGGLE POP - This is the function that runs to toggle popup overlay
 * 
 */
function togglePop(con){
	confirmContainer.visible = con;
}


/*!
 * 
 * DISPLAY PAGES - This is the function that runs to display pages
 * 
 */
var curPage=''
function goPage(page){
	curPage=page;
	
	mainContainer.visible = false;
	gameContainer.visible = false;
	resultContainer.visible = false;
	changeColorContainer.visible = false;
	
	var targetContainer = null;
	switch(page){
		case 'main':
			targetContainer = mainContainer;
			stopMusicLoop("musicGame");
			playMusicLoop("musicMain");
		break;

		case 'game':
			targetContainer = gameContainer;
			startGame();
			stopMusicLoop("musicMain");
			playMusicLoop("musicGame");
		break;
		
		case 'ADgame':
			targetContainer = gameContainer;
			resumeGame();
			stopMusicLoop("musicMain");
			// playMusicLoop("musicGame");
		break;
		case 'color':
			targetContainer = changeColorContainer;
			
		break;

		case 'result':
			buttonContinue.visible = false;
			setTimeout(() => {buttonContinue.visible = true}, 2000);
			targetContainer = resultContainer;
			togglePop(false);
			playSound('soundResult');
			

			tweenData.tweenScore = 0;
			TweenMax.to(tweenData, .5, {tweenScore:playerData.score, overwrite:true, onUpdate:function(){
				resultDescTxt.text = textDisplay.resultDesc.replace('[NUMBER]', addCommas(Math.floor(tweenData.tweenScore)));
			}});
			

			saveGame(playerData.score);

			
			
			localStorage.setItem("Current Score", parseInt(playerData.score));

			let bestScore = localStorage.getItem("Best Score");
			if(bestScore > parseInt(playerData.score)){
				
			}else{
				localStorage.setItem("Best Score", parseInt(playerData.score));
			}

		break;
	}
	
	if(targetContainer != null){
		targetContainer.visible = true;
		targetContainer.alpha = 0;
		TweenMax.to(targetContainer, .5, {alpha:1, overwrite:true});
	}
	
	resizeCanvas();
}

/*!
 * 
 * START GAME - This is the function that runs to start game
 * 
 */

bestScoreStorage = window.localStorage;



function startGame(){
	gameData.paused = false;
	gameData.squareSize = gameSettings.world.size;
	gameData.totalColumn = gameSettings.world.column;
	gameData.totalRow = gameSettings.world.row;
	gameData.puzzleArr = [];
	gameData.puzzleIndex = 0;
	gameData.puzzleReset = true;
	gameData.firstMove = true;

	playerData.score = 0;
	gameData.levelNum = 0;
	gameData.moveSpeed = 0;
	gameData.lastMove = "";
	updateGameScore();
	prepareLevel();
	preparePuzzle();
	playSound('soundStart');
	if($.browser.mobile || isTablet){
		gameInstructionTxt.text = textDisplay.instructionMobile;
	}else{
		gameInstructionTxt.text = textDisplay.instructionDesktop;
	}
	toggleInstruction(true);
}

function resumeGame(){
	gameData.paused = false;
	gameData.squareSize = gameSettings.world.size;
	gameData.totalColumn = gameSettings.world.column;
	gameData.totalRow = gameSettings.world.row;
	gameData.puzzleArr = [];
	gameData.puzzleIndex = 0;
	gameData.puzzleReset = true;
	gameData.firstMove = true;

	
	if(playerData.score == 0){
	playerData.score = 200
	}else{
		playerData.score = playerData.score;
	}
	gameData.levelNum = 0;
	gameData.moveSpeed = 0;
	gameData.lastMove = "";
	updateGameScore();
	prepareLevel();
	preparePuzzle();
	playSound('soundStart');
	if($.browser.mobile || isTablet){
		gameInstructionTxt.text = textDisplay.instructionMobile;
	}else{
		gameInstructionTxt.text = textDisplay.instructionDesktop;
	}
	toggleInstruction(true);
}



// function gameFunBestScore(){
// 	var gameBestScore = 0;
// 	if(gameBestScore < playerData.score){
// 	gameBestScore = gameBestScore
// 	}
// 	else{
// 	gameBestScore = playerData.score
// 	}
// 	gameBestScoreTxt.text = String(playerData.score)
// }


function toggleInstruction(con){
	if(con){
		animateInstruction(gameInstructionTxt);
	}else{
		TweenMax.killTweensOf(gameInstructionTxt);
		gameInstructionTxt.alpha = 0;
	}
}

function animateInstruction(obj){
	obj.alpha = .5;
	var tweenSpeed = .3;
	TweenMax.to(obj, tweenSpeed, {alpha:.2, overwrite:true, onComplete:function(){
		TweenMax.to(obj, tweenSpeed, {alpha:.5, overwrite:true, onComplete:animateInstruction, onCompleteParams:[obj]});
	}});
}

function prepareLevel(){
	gameData.level = {
		level:gameSettings.levels[gameData.levelNum].level,
		nextTarget:gameSettings.levels[gameData.levelNum].nextTarget,
		speedIncrease:gameSettings.levels[gameData.levelNum].speedIncrease,
		score:gameSettings.levels[gameData.levelNum].score,
	}
}

function preparePuzzle(){
	if(gameData.puzzleReset){
		gameData.puzzleArr = [];
		gameData.puzzleReset = false;

		gameData.puzzleIndex = 0;
		for(var n=0; n<puzzles_arr.length; n++){
			if(puzzles_arr[n].level == gameData.level.level){
				gameData.puzzleArr.push({level:puzzles_arr[n].level, index:n})
			}
		}
		shuffle(gameData.puzzleArr);
	}

	gameData.playerMove = false;
	gameData.animating = false;
	gameData.touchCon = false;
	gameData.checkHitCon = false;
	gameData.checkFitCon = false;
	gameData.checkSafeCon = false;
	gameData.puzzleMove = false;
	gameData.moveControl = {
		left:false,
		right:false,
		up:false,
		down:false
	}
	
	gameData.squares = [];
	setupWorld();
	buildPuzzle();

	if(!gameData.firstMove){
		gameData.playerMove = true;
		gameData.puzzleMove = true;
	}else{
		gameData.playerMove = true;
	}
}

function setupWorld(){
	if(viewport.isLandscape){
		gameData.world = {
			startY:80,
			centerY:400,
			checkY:0,
			endY:600,
			aspectRange:0,
			aspectHeight:80,
			aspectWallHeight:50,
			speed:gameSettings.world.puzzleSpeed,
			speedDefault:gameSettings.world.puzzleSpeed,
		};
	}else{
		gameData.world = {
			startY:80,
			centerY:500,
			checkY:0,
			endY:820,
			aspectRange:0,
			aspectHeight:80,
			aspectWallHeight:50,
			speed:gameSettings.world.puzzleSpeed+.3,
			speedDefault:gameSettings.world.puzzleSpeed+.3,
		};
	}

	gameData.world.aspectRange = gameData.world.centerY/10;
	buildGuides();

	for(var n=0; n<gameData.squares.length; n++){
		var thisSquare = gameData.squares[n];
		if(thisSquare.type != 2){
			thisSquare.depth = gameData.world.centerY;
			thisSquare.thick = gameData.world.aspectHeight;
		}
	}
}

 /*!
 * 
 * STOP GAME - This is the function that runs to stop play game
 * 
 */
function stopGame(){
	TweenMax.killAll(false, true, false);
	gameData.paused = true;
}

function saveGame(score){
	if ( typeof toggleScoreboardSave == 'function' ) { 
		$.scoreData.score = score;
		if(typeof type != 'undefined'){
			$.scoreData.type = type;
		}
		toggleScoreboardSave(true);
	}

	/*$.ajax({
      type: "POST",
      url: 'saveResults.php',
      data: {score:score},
      success: function (result) {
          console.log(result);
      }
    });*/
}

/*!
 * 
 * RESIZE GAME LAYOUT - This is the function that runs for resize game layout
 * 
 */
function resizeGameLayout(){
	if(viewport.isLandscape){
		worldContainer.x = canvasW/2;
		worldContainer.y = canvasH/100 * 20;

		gameScoreTxt.x = canvasW/2;
		gameScoreTxt.y = offset.y + 70;

		gameBestScoreTxt.x = canvasW/5;
		gameBestScoreTxt.y = offset.y + 70;

		gameInstructionTxt.x = canvasW/2;
		gameInstructionTxt.y = canvasH/100 * 80;

		bgGradient.y = canvasH/100 * 30;
	}else{
		worldContainer.x = canvasW/2;
		worldContainer.y = canvasH/100 * 20;

		gameBestScoreTxt.x = canvasW/2.3;
		gameBestScoreTxt.y = offset.y + 65;

		gameScoreTxt.x = canvasW/2;
		gameScoreTxt.y = offset.y + 70;

		gameInstructionTxt.x = canvasW/2;
		gameInstructionTxt.y = canvasH/100 * 80;

		bgGradientP.y = canvasH/100 * 30;
	}
}

/*!
 * 
 * BUILD GUIDES - This is the function that runs to build guides
 * 
 */
function buildGuides(){
	guideContainer.removeAllChildren();
	guideContainer.alpha = .3;

	var squareSize = gameData.squareSize;
	var aspectRange = gameData.world.aspectRange;

	var startAspectRatio = 1;
	var endAspectRatio = 1;
	var strokeNum = 2;
	var strokeColor = "#fff";
	var fillColor = "#fff";
	var startColumn = -3;
	var startDepth = gameData.world.startY;
	var endDepth = gameData.world.endY;

	var guideFill = new createjs.Shape();
	guideFill.graphics.beginFill(fillColor);
	guideFill.graphics.mt(-((4 * squareSize) * aspectRatio), gameData.world.centerY);
	guideFill.graphics.lt(((4 * squareSize) * aspectRatio), gameData.world.centerY);
	guideFill.alpha = .3;
	guideContainer.addChild(guideFill);

	for(var n=0; n<7; n++){
		startAspectRatio = (startDepth / aspectRange) * .1;
		endAspectRatio = (endDepth / aspectRange) * .1;

		var startX = (Math.abs(startColumn)-1) * ((squareSize) * startAspectRatio);
		var startY = startDepth;
		var endX = (Math.abs(startColumn)-1) * ((squareSize) * endAspectRatio);
		var endY = endDepth;

		if(startColumn < 0){
			startX = -(Math.abs(startColumn) * ((squareSize) * startAspectRatio));
			endX = -(Math.abs(startColumn) * ((squareSize) * endAspectRatio));
		}

		startColumn++;
		startColumn = startColumn == 0 ? 1 : startColumn;

		var newGuide = new createjs.Shape();
		newGuide.graphics.setStrokeStyle(strokeNum,'round','round').beginStroke(strokeColor);
		newGuide.graphics.mt(startX, startY);
		newGuide.graphics.lt(endX, endY);

		if(n == 0){
			guideFill.graphics.mt(startX, startY);
			guideFill.graphics.lt(endX, endY);
		}else if(n == 6){
			guideFill.graphics.lt(endX, endY);
			guideFill.graphics.lt(startX, startY);
		}
		guideContainer.addChild(newGuide);
	}

	var aspectRatio = (gameData.world.centerY / aspectRange) * .1;
	var aspectRatioTopHeight = (gameData.world.centerY / aspectRange) * .05;
	aspectRatioTopHeight = aspectRatioTopHeight * aspectRatio;

	var guideCenterFill = new createjs.Shape();
	guideCenterFill.graphics.beginFill(fillColor);
	guideCenterFill.alpha = .5;

	var newCenterB = new createjs.Shape();
	newCenterB.graphics.setStrokeStyle(strokeNum,'round','round').beginStroke(strokeColor);
	newCenterB.graphics.mt(-((4 * squareSize) * aspectRatio), gameData.world.centerY);
	newCenterB.graphics.lt(((4 * squareSize) * aspectRatio), gameData.world.centerY);

	guideCenterFill.graphics.mt(-((3 * squareSize) * aspectRatio), gameData.world.centerY);
	guideCenterFill.graphics.lt(((3 * squareSize) * aspectRatio), gameData.world.centerY);

	var endY = gameData.world.centerY - (gameData.world.aspectHeight * aspectRatioTopHeight);
	aspectRatio = (endY / aspectRange) * .1;

	var newCenterA = new createjs.Shape();
	newCenterA.graphics.setStrokeStyle(strokeNum,'round','round').beginStroke(strokeColor);
	newCenterA.graphics.mt(-((4 * squareSize) * aspectRatio), endY);
	newCenterA.graphics.lt(((4 * squareSize) * aspectRatio), endY);

	guideCenterFill.graphics.lt(((3 * squareSize) * aspectRatio), endY);
	guideCenterFill.graphics.lt(-((3 * squareSize) * aspectRatio), endY);

	guideContainer.addChild(guideCenterFill, newCenterA, newCenterB);
}

/*!
 * 
 * BUILD PUZZLE - This is the function that runs to build puzzle
 * 
 */
function buildPuzzle(){
	objectsContainer.removeAllChildren();

	gameData.reverseCon = randomBoolean();
	var puzzleIndex = gameData.puzzleArr[gameData.puzzleIndex].index;
	gameData.puzzle = puzzles_arr[puzzleIndex].puzzle;
	for(var c=0; c<gameData.totalColumn; c++){
		for(var r=0; r<gameData.totalRow; r++){
			var blockCon = true;
			for(var n=0; n<gameData.puzzle.length; n++){
				var thisColumn = gameData.puzzle[n].c;
				thisColumn = gameData.reverseCon == true ? (gameData.totalColumn-1)-thisColumn : thisColumn;
				if(gameData.puzzle[n].r == r && thisColumn == c){
					blockCon = false;
					if(gameData.puzzle[n].visible){
						createBlock(c,r,gameData.world.centerY,gameData.world.aspectHeight,1);
					}
				}
			}
			if(blockCon){
				createBlock(c,r,gameData.world.startY,gameData.world.aspectWallHeight,2);
			}
		}
	}

	//createBlock(0,2,gameData.world.centerY,gameData.world.aspectHeight,1);
	//createBlock(0,1,gameData.world.centerY,gameData.world.aspectHeight,1);
	//createBlock(0,0,gameData.world.centerY,gameData.world.aspectHeight,1);

	var playerIndex = Math.floor(Math.random() * puzzles_arr[puzzleIndex].player.length);
	var thisColumn = puzzles_arr[puzzleIndex].player[playerIndex].c;
	thisColumn = gameData.reverseCon == true ? (gameData.totalColumn-1)-thisColumn : thisColumn;
	createBlock(thisColumn,puzzles_arr[puzzleIndex].player[playerIndex].r,gameData.world.centerY,gameData.world.aspectHeight,0);
}

function createBlock(c,r,depth,thick,type){
	var newSquare = new createjs.Container();
	gameData.squares.push({type:type, c:c, r:r, x:0, y:0, block:false, offsetX:0, offsetY:0, depth:depth, thick:thick, container:newSquare, front:[], top:[], left:[], right:[], back:[]});
	var squareIndex = gameData.squares.length-1;

	for(var n=0; n<4; n++){
		var frontPos = {x:0, y:0};
		var topPos = {x:0, y:0};
		var leftPos = {x:0, y:0};
		var rightPos = {x:0, y:0};
		var backPos = {x:0, y:0};
		gameData.squares[squareIndex].front.push(frontPos);
		gameData.squares[squareIndex].top.push(topPos);
		gameData.squares[squareIndex].left.push(leftPos);
		gameData.squares[squareIndex].right.push(rightPos);
		gameData.squares[squareIndex].back.push(backPos);
	}

	gameData.squares[squareIndex].frontShape = new createjs.Shape();
	gameData.squares[squareIndex].topShape = new createjs.Shape();
	gameData.squares[squareIndex].leftShape = new createjs.Shape();
	gameData.squares[squareIndex].rightShape = new createjs.Shape();
	gameData.squares[squareIndex].backShape = new createjs.Shape();
	gameData.squares[squareIndex].container.addChild(gameData.squares[squareIndex].leftShape, gameData.squares[squareIndex].rightShape, gameData.squares[squareIndex].topShape, gameData.squares[squareIndex].frontShape);
	
	if(type == 0){
		gameData.player = gameData.squares[squareIndex];
		gameData.player.due = "";

		gameData.player.container.cursor = "pointer";
		gameData.player.container.addEventListener("mousedown", function(evt) {
			toggleDragEvent(evt, 'drag')
		});
		gameData.player.container.addEventListener("pressup", function(evt) {
			toggleDragEvent(evt, 'drop')
		});
	}
	objectsContainer.addChild(newSquare);
}

function toggleDragEvent(obj, con){
	if(gameData.paused){
		return;
	}
	
	switch(con){
		case 'drag':
			gameData.touchCon = true;
		break;
		
		case 'drop':
			gameData.touchCon = false;
		break;
	}
}

/*!
 * 
 * UPDATE GAME - This is the function that runs to loop game update
 * 
 */
function updateGame(event){
	if(!gameData.paused){
		updateShapes();
		checkControl();
	}
}

function updateShapes(){
	var squareSize = gameData.squareSize;
	var aspectRange = gameData.world.aspectRange;
	
	var aspectRatio = 0;
	var aspectRatioY = 0;
	var aspectRatioTopHeight = 0;
	var speed = 0;
	var centerColumn = gameData.totalColumn/2;

	var checkHitCon = false;
	var checkFitCon = false;
	for(var n=0; n<gameData.squares.length; n++){
		var thisSquare = gameData.squares[n];
		var frontPos = gameData.squares[n].front;
		var backPos = gameData.squares[n].back;
		var topPos = gameData.squares[n].top;
		var leftPos = gameData.squares[n].left;
		var rightPos = gameData.squares[n].right;

		var thisColumn = thisSquare.c+1;
		if(thisColumn <= centerColumn){
			thisColumn = (thisColumn-1) - centerColumn;
		}else{
			thisColumn = thisColumn - centerColumn;
		}
		var thisRow = thisSquare.r+1;

		gameData.world.checkY = gameData.world.centerY - (gameData.world.aspectHeight * aspectRatioTopHeight);
		aspectRatio = (thisSquare.depth / aspectRange) * .1;
		var perspectiveRange = (thisSquare.depth - gameData.world.startY) * .0005;
		aspectRatioY = aspectRatio-perspectiveRange;

		speed = (thisSquare.depth / aspectRange) * (gameData.world.speed);

		thisSquare.x = (Math.abs(thisColumn)-1) * ((squareSize/2) * aspectRatio);
		thisSquare.y = -((thisRow-1) * (squareSize * aspectRatioY));

		if(thisColumn < 0){
			thisSquare.x = -(Math.abs(thisColumn) * ((squareSize/2) * aspectRatio));
		}
		thisSquare.x = thisSquare.x + ((thisSquare.offsetX/2) * aspectRatio);

		var frontColor = gameSettings.colors.wall[0];
		var topColor = gameSettings.colors.wall[1];
		var sideColor = gameSettings.colors.wall[2];

		if(thisSquare.type == 0){
			frontColor = gameSettings.colors.player[0];
			topColor = gameSettings.colors.player[1];
			sideColor = gameSettings.colors.player[2];
		}else if(thisSquare.type == 1){
			frontColor = gameSettings.colors.puzzle[0];
			topColor = gameSettings.colors.puzzle[1];
			sideColor = gameSettings.colors.puzzle[2];
		}

		if(thisSquare.block){
			frontColor = gameSettings.colors.block[0];
			topColor = gameSettings.colors.block[1];
			sideColor = gameSettings.colors.block[2];
		}

		thisSquare.frontShape.graphics.clear().beginFill(frontColor);
		thisSquare.backShape.graphics.clear().beginFill(sideColor);
		thisSquare.topShape.graphics.clear().beginFill(topColor);
		thisSquare.leftShape.graphics.clear().beginFill(sideColor);
		thisSquare.rightShape.graphics.clear().beginFill(sideColor);

		//position
		thisSquare.frontShape.x = thisSquare.x;
		thisSquare.frontShape.y = thisSquare.y;
		frontPos[0].x = thisSquare.x;
		frontPos[0].y = thisSquare.depth + ((thisSquare.offsetY) * aspectRatioY);
		frontPos[1].x = frontPos[0].x;
		frontPos[1].y = frontPos[0].y - (squareSize * aspectRatioY);
		frontPos[2].x = frontPos[0].x + (squareSize * aspectRatio);
		frontPos[2].y = frontPos[0].y - (squareSize * aspectRatioY);
		frontPos[3].x = frontPos[0].x + (squareSize * aspectRatio);
		frontPos[3].y = frontPos[0].y;

		//back position
		aspectRatioTopHeight = (thisSquare.depth / aspectRange) * .05;
		aspectRatioTopHeight = aspectRatioTopHeight * aspectRatio;
		
		var backY = (thisSquare.depth) - (thisSquare.thick * aspectRatioTopHeight);
		var backAspectRatio = (backY / aspectRange) * .1;
		var backX = (Math.abs(thisColumn)-1) * ((squareSize/2) * backAspectRatio);

		if(thisColumn < 0){
			backX = -(Math.abs(thisColumn) * ((squareSize/2) * backAspectRatio));
		}
		backX = backX + (backX - thisSquare.x);
		backX = backX + (thisSquare.offsetX * backAspectRatio);
		backY = backY + (thisSquare.offsetY * aspectRatioY);
		
		thisSquare.backShape.x = thisSquare.x;
		thisSquare.backShape.y = thisSquare.y;
		backPos[0].x = backX;
		backPos[0].y = backY;
		backPos[1].x = backPos[0].x;
		backPos[1].y = backPos[0].y - (squareSize * aspectRatioY);
		backPos[2].x = backPos[0].x + (squareSize * backAspectRatio);
		backPos[2].y = backPos[0].y - (squareSize * aspectRatioY);
		backPos[3].x = backPos[0].x + (squareSize * backAspectRatio);
		backPos[3].y = backPos[0].y;

		thisSquare.topShape.x = thisSquare.x;
		thisSquare.topShape.y = thisSquare.y;
		topPos[0].x = frontPos[1].x;
		topPos[0].y = frontPos[1].y;
		topPos[1].x = backPos[1].x;
		topPos[1].y = backPos[1].y;
		topPos[2].x = backPos[2].x;
		topPos[2].y = backPos[2].y;
		topPos[3].x = frontPos[2].x;
		topPos[3].y = frontPos[2].y;

		thisSquare.leftShape.x = thisSquare.x;
		thisSquare.leftShape.y = thisSquare.y;
		leftPos[0].x = backPos[0].x;
		leftPos[0].y = backPos[0].y;
		leftPos[1].x = backPos[1].x;
		leftPos[1].y = backPos[1].y;
		leftPos[2].x = frontPos[1].x;
		leftPos[2].y = frontPos[1].y;
		leftPos[3].x = frontPos[0].x;
		leftPos[3].y = frontPos[0].y;

		thisSquare.rightShape.x = thisSquare.x;
		thisSquare.rightShape.y = thisSquare.y;
		rightPos[0].x = frontPos[3].x;
		rightPos[0].y = frontPos[3].y;
		rightPos[1].x = frontPos[2].x;
		rightPos[1].y = frontPos[2].y;
		rightPos[2].x = backPos[2].x;
		rightPos[2].y = backPos[2].y;
		rightPos[3].x = backPos[3].x;
		rightPos[3].y = backPos[3].y;

		//shape
		var extra = 1;
		thisSquare.frontShape.graphics.mt(frontPos[0].x-extra, frontPos[0].y+extra);
		thisSquare.frontShape.graphics.lt(frontPos[1].x-extra, frontPos[1].y-extra);
		thisSquare.frontShape.graphics.lt(frontPos[2].x+extra, frontPos[2].y-extra);
		thisSquare.frontShape.graphics.lt(frontPos[3].x+extra, frontPos[3].y+extra);
		thisSquare.frontShape.graphics.lt(frontPos[0].x-extra, frontPos[0].y+extra);

		thisSquare.backShape.graphics.mt(backPos[0].x-extra, backPos[0].y+extra);
		thisSquare.backShape.graphics.lt(backPos[1].x-extra, backPos[1].y-extra);
		thisSquare.backShape.graphics.lt(backPos[2].x+extra, backPos[2].y-extra);
		thisSquare.backShape.graphics.lt(backPos[3].x+extra, backPos[3].y+extra);
		thisSquare.backShape.graphics.lt(backPos[0].x-extra, backPos[0].y+extra);

		thisSquare.topShape.graphics.mt(topPos[0].x-extra, topPos[0].y);
		thisSquare.topShape.graphics.lt(topPos[1].x-extra, topPos[1].y);
		thisSquare.topShape.graphics.lt(topPos[2].x+extra, topPos[2].y);
		thisSquare.topShape.graphics.lt(topPos[3].x+extra, topPos[3].y);
		thisSquare.topShape.graphics.lt(topPos[0].x-extra, topPos[0].y);

		thisSquare.leftShape.graphics.mt(leftPos[0].x-extra, leftPos[0].y+extra);
		thisSquare.leftShape.graphics.lt(leftPos[1].x-extra, leftPos[1].y-extra);
		thisSquare.leftShape.graphics.lt(leftPos[2].x+extra, leftPos[2].y-extra);
		thisSquare.leftShape.graphics.lt(leftPos[3].x+extra, leftPos[3].y+extra);
		thisSquare.leftShape.graphics.lt(leftPos[0].x-extra, leftPos[0].y+extra);

		thisSquare.rightShape.graphics.mt(rightPos[0].x-extra, rightPos[0].y+extra);
		thisSquare.rightShape.graphics.lt(rightPos[1].x-extra, rightPos[1].y-extra);
		thisSquare.rightShape.graphics.lt(rightPos[2].x+extra, rightPos[2].y-extra);
		thisSquare.rightShape.graphics.lt(rightPos[3].x+extra, rightPos[3].y+extra);
		thisSquare.rightShape.graphics.lt(rightPos[0].x-extra, rightPos[0].y+extra);

		var scale = 1;
		thisSquare.leftShape.scaleX = thisSquare.leftShape.scaleY = scale;
		thisSquare.rightShape.scaleX = thisSquare.rightShape.scaleY = scale;
		thisSquare.topShape.scaleX = thisSquare.topShape.scaleY = scale;
		thisSquare.frontShape.scaleX = thisSquare.frontShape.scaleY = scale;

		if(thisSquare.type == 2 && gameData.puzzleMove){
			thisSquare.depth += speed;

			if(thisSquare.depth >= gameData.world.checkY){
				if(!gameData.checkHitCon){
					//thisSquare.depth = gameData.world.checkY;
					checkHitCon = true;
				}
			}
			
			if(thisSquare.depth >= gameData.world.centerY){
				if(!gameData.checkFitCon){
					//thisSquare.depth = gameData.world.centerY;
					checkFitCon = true;
				}
			}
		}
	}

	if(checkHitCon){
		checkHitPlayer();
	}
	if(checkFitCon){
		checkFitHole();
	}

	updateObjectChild();
}

function checkHitPlayer(){
	if(!gameData.checkHitCon){
		gameData.checkHitCon = true;

		var playerC = gameData.player.c;
		var playerR = gameData.player.r;
		gameData.checkSafeCon = false;
		for(var n=0; n<gameData.puzzle.length; n++){
			var thisColumn = gameData.puzzle[n].c;
			thisColumn = gameData.reverseCon == true ? (gameData.totalColumn-1)-thisColumn : thisColumn;
			if(gameData.puzzle[n].r == playerR && thisColumn == playerC){
				gameData.checkSafeCon = true;
			}
		}

		if(!gameData.checkSafeCon){
			gameData.playerMove = false;
			for(var n=0; n<gameData.squares.length; n++){
				var thisSquare = gameData.squares[n];
				if(thisSquare.type == 2 && thisSquare.r == playerR && thisSquare.c == playerC){
					thisSquare.block =  true;
					playSound('soundFail');
					animateBlink(thisSquare.container);
				}
			}

			gameData.world.speed = -(gameData.world.speed);
			TweenMax.to(gameData.world, 1, {speed:0, overwrite:true, onComplete:function(){
				endGame();
			}});
		}
	}
}

function checkFitHole(){
	if(!gameData.checkFitCon){
		gameData.checkFitCon = true;

		if(gameData.checkSafeCon){
			var randomSound = Math.floor(Math.random()*3)+1;
			playSound('soundSuccess'+randomSound);
			playerData.score += gameData.level.score;
			updateGameScore();
			TweenMax.to(gameData.world, .5, {speed:0, overwrite:true, onComplete:function(){
				prepareNextPuzzle();
			}});
		}
	}
}

function animateBlink(obj){
	obj.alpha = 1;
	var tweenSpeed = .1;
	TweenMax.to(obj, tweenSpeed, {alpha:.5, overwrite:true, onComplete:function(){
		TweenMax.to(obj, tweenSpeed, {alpha:1, overwrite:true, onComplete:animateBlink, onCompleteParams:[obj]});
	}});
}

function prepareNextPuzzle(){
	gameData.puzzleMove = false;
	gameData.level.nextTarget--;
	if(gameData.level.nextTarget <= 0){
		gameData.levelNum++;
		gameData.levelNum = gameData.levelNum > gameSettings.levels.length-1 ? gameSettings.levels.length-1 : gameData.levelNum;
		prepareLevel();
		gameData.puzzleReset = true;
	}else{
		gameData.puzzleIndex++;
		if(gameData.puzzleIndex > gameData.puzzleArr.length-1){
			gameData.puzzleReset = true;
		}
	}

	gameData.moveSpeed += gameData.level.speedIncrease;
	gameData.world.speed = gameData.world.speedDefault + gameData.moveSpeed;
	console.log(gameData.levelNum, gameData.world.speed)
	preparePuzzle();
}

function updateObjectChild(){
	var sortArr = [];
	for(var n=0; n<gameData.squares.length; n++){
		sortArr.push({container:gameData.squares[n].container, depth:gameData.squares[n].depth, x:Math.abs(gameData.squares[n].x), y:gameData.squares[n].y});
	}

	sortOnObject(sortArr,"x");
	sortOnObject(sortArr,"y");
	sortOnObject(sortArr,"depth", true);
	
	for(var n=0; n<sortArr.length; n++){
		objectsContainer.setChildIndex(sortArr[n].container, 0);
	}
}

/*!
 * 
 * UPDATE CONTROL - This is the function that runs to loop game control
 * 
 */
function checkControl(){
	var dir = "";
	if(gameData.moveControl.left){
		dir = "left";
	}

	if(gameData.moveControl.right){
		dir = "right";
	}

	if(gameData.moveControl.up){
		dir = "up";
	}

	if(gameData.moveControl.down){
		dir = "down";
	}

	if(dir != ""){
		gameData.player.due = dir;
		checkNextMove(true);
	}
}

function checkNextMove(con){
	if(gameData.player.due != "" && !gameData.animating){
		var nextC = gameData.player.c;
		var nextR = gameData.player.r;
		var proceedAnimation = true;

		if(gameData.player.due == "left"){
			nextC--;
			if(nextC < 1){
				proceedAnimation = false;
			}
		}else if(gameData.player.due == "right"){
			nextC++;
			if(nextC > gameData.totalColumn-2){
				proceedAnimation = false;
			}
		}else if(gameData.player.due == "up"){
			nextR++;
			if(nextR > gameData.totalRow-1){
				proceedAnimation = false;
			}
		}else if(gameData.player.due == "down"){
			nextR--;
			if(nextR < 0){
				proceedAnimation = false;
			}
		}

		for(var n=0; n<gameData.puzzle.length; n++){
			var thisColumn = gameData.puzzle[n].c;
			thisColumn = gameData.reverseCon == true ? (gameData.totalColumn-1)-thisColumn : thisColumn;
			if(gameData.puzzle[n].r == nextR && thisColumn == nextC && gameData.puzzle[n].visible){
				proceedAnimation = false;
			}
		}

		if(nextR > 0){
			var canMove = false;
			for(var t=0; t<8; t++){
				var tryNextC = nextC;
				var tryNextR = nextR;
				var possibleArr = [];
				if(t == 0){
					//right
					tryNextC++;
				}else if(t == 1){
					//left
					tryNextC--;
				}else if(t == 2){
					//up
					tryNextR++;
				}else if(t == 3){
					//down
					tryNextR--;
				}else if(t == 4){
					//tl
					tryNextC--;
					tryNextR--;
				}else if(t == 5){
					//tr
					tryNextC++;
					tryNextR--;
				}else if(t == 6){
					//bl
					tryNextC--;
					tryNextR++;
				}else if(t == 7){
					//br
					tryNextC++;
					tryNextR++;
				}

				if(gameData.player.due == "left"){
					possibleArr = [2,3,5,7];
				}else if(gameData.player.due == "right"){
					possibleArr = [2,3,4,6];
				}else if(gameData.player.due == "up"){
					possibleArr = [0,1,4,5];
				}else if(gameData.player.due == "down"){
					possibleArr = [0,1,6,7];
				}

				for(var n=0; n<gameData.squares.length; n++){
					var thisSquare = gameData.squares[n];
					if(thisSquare.type == 1){
						if(thisSquare.r == tryNextR && thisSquare.c == tryNextC){
							if(possibleArr.indexOf(t) != -1){
								canMove = true;
							}
						}
					}
				}
			}

			if(!canMove){
				proceedAnimation = false;
			}
		}

		if(proceedAnimation){
			gameData.lastMove = "";
			moveSquare(con, gameData.player.due, nextC, nextR);
		}else{
			if(gameData.player.due != gameData.lastMove){
				gameData.lastMove = gameData.player.due;
				playSound('soundMoveError');
			}
		}
	}
}

function moveSquare(con, dir, c, r){
	if(gameData.firstMove){
		gameData.firstMove = false;
		gameData.puzzleMove = true;
		toggleInstruction(false);
	}

	playSound('soundMove');
	gameData.animating = true;

	var offsetX = 0;
	var offsetY = 0;
	if(dir == "left"){
		offsetX = -gameData.squareSize;
	}else if(dir == "right"){
		offsetX = gameData.squareSize;
	}else if(dir == "up"){
		offsetY = -gameData.squareSize;
	}else if(dir == "down"){
		offsetY = gameData.squareSize;
	}

	var tweenSpeed = con == true ? gameSettings.world.keyboardSpeed : gameSettings.world.touchSpeed;
	TweenMax.to(gameData.player, tweenSpeed, {offsetX:offsetX, offsetY:offsetY, ease:Linear.easeNone, overwrite:true, onComplete:function(){
		gameData.animating = false;
		gameData.player.offsetX = 0;
		gameData.player.offsetY = 0;
		gameData.player.c = c;
		gameData.player.r = r;
	}});
}

/*!
 * 
 * GAME SCORE - This is the function that runs for game score
 * 
 */
function updateGameScore(){
	TweenMax.to(tweenData, .5, {tweenScore:playerData.score, overwrite:true, onUpdate:function(){
		gameScoreTxt.text = textDisplay.score.replace("[NUMBER]", addCommas(Math.floor(tweenData.tweenScore)));
	}});

}

// function bestGameScore() {
	
// }

/*!
 * 
 * END GAME - This is the function that runs for game end
 * 
 */
function endGame(){
	gameData.puzzleMove = false;
	TweenMax.to(gameContainer, 1, {overwrite:true, onComplete:function(){
		goPage('result')
	}});
}

/*!
 * 
 * MILLISECONDS CONVERT - This is the function that runs to convert milliseconds to time
 * 
 */
function millisecondsToTimeGame(milli) {
	var milliseconds = milli % 1000;
	var seconds = Math.floor((milli / 1000) % 60);
	var minutes = Math.floor((milli / (60 * 1000)) % 60);
	
	if(seconds<10){
		seconds = '0'+seconds;  
	}
	
	if(minutes<10){
		minutes = '0'+minutes;  
	}
	
	return seconds;
}

/*!
 * 
 * OPTIONS - This is the function that runs to toggle options
 * 
 */

function toggleOption(){
	if(optionsContainer.visible){
		optionsContainer.visible = false;
	}else{
		optionsContainer.visible = true;
	}
}


/*!
 * 
 * OPTIONS - This is the function that runs to mute and fullscreen
 * 
 */
function toggleSoundMute(con){
	buttonSoundOff.visible = false;
	buttonSoundOn.visible = false;
	toggleSoundInMute(con);
	if(con){
		buttonSoundOn.visible = true;
	}else{
		buttonSoundOff.visible = true;	
	}
}

function toggleMusicMute(con){
	buttonMusicOff.visible = false;
	buttonMusicOn.visible = false;
	toggleMusicInMute(con);
	if(con){
		buttonMusicOn.visible = true;
	}else{
		buttonMusicOff.visible = true;	
	}
}

function toggleFullScreen() {
  if (!document.fullscreenElement &&    // alternative standard method
      !document.mozFullScreenElement && !document.webkitFullscreenElement && !document.msFullscreenElement ) {  // current working methods
    if (document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen();
    } else if (document.documentElement.msRequestFullscreen) {
      document.documentElement.msRequestFullscreen();
    } else if (document.documentElement.mozRequestFullScreen) {
      document.documentElement.mozRequestFullScreen();
    } else if (document.documentElement.webkitRequestFullscreen) {
      document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
    }
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    }
  }
}

/*!
 * 
 * SHARE - This is the function that runs to open share url
 * 
 */
function share(action){
	gtag('event','click',{'event_category':'share','event_label':action});
	
	var loc = location.href
	loc = loc.substring(0, loc.lastIndexOf("/") + 1);
	
	var title = '';
	var text = '';
	
	title = shareTitle.replace("[SCORE]", addCommas(playerData.score));
	text = shareMessage.replace("[SCORE]", addCommas(playerData.score));
	
	var shareurl = '';
	
	if( action == 'twitter' ) {
		shareurl = 'https://twitter.com/intent/tweet?url='+loc+'&text='+text;
	}else if( action == 'facebook' ){
		shareurl = 'https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(loc+'share.php?desc='+text+'&title='+title+'&url='+loc+'&thumb='+loc+'share.jpg&width=590&height=300');
	}else if( action == 'google' ){
		shareurl = 'https://plus.google.com/share?url='+loc;
	}else if( action == 'whatsapp' ){
		shareurl = "whatsapp://send?text=" + encodeURIComponent(text) + " - " + encodeURIComponent(loc);
	}
}